"use client";
import { useEffect, useState, useCallback } from "react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, ReferenceLine, Cell,
} from "recharts";
import { ChevronLeft, ChevronRight, Info } from "lucide-react";
import { cn, formatCurrency, formatR } from "@/lib/utils";
import Link from "next/link";
import { KpiRow, TradeScoreCard } from "@/components/dashboard/KpiCards";
import {
  format, startOfMonth, endOfMonth, eachDayOfInterval,
  getDay, addMonths, subMonths,
} from "date-fns";

const PERIODS = [
  { label: "7D", value: "7d" },
  { label: "1M", value: "1m" },
  { label: "3M", value: "3m" },
  { label: "YTD", value: "ytd" },
  { label: "All", value: "all" },
];

const CURVE_COLOR = "#6366f1";
const DAYS_OF_WEEK_FULL = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

const TOOLTIP_STYLE = {
  fontSize: 11,
  borderRadius: 8,
  backgroundColor: '#0f0f1a',
  border: '1px solid rgba(255,255,255,0.12)',
  color: '#ffffff',
  boxShadow: '0 4px 16px rgba(0,0,0,0.6)',
};

function StatCard({ label, value, sub, color }: { label: string; value: string; sub?: string; color?: string }) {
  return (
    <div className="bg-card border rounded-xl p-3 card-hover">
      <p className="text-[10px] text-muted-foreground mb-0.5">{label}</p>
      <p className={cn("text-base font-semibold tracking-tight truncate", color ?? "text-foreground")}>{value}</p>
      {sub && <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{sub}</p>}
    </div>
  );
}

function CalendarHeatmap({ calendarData, currency }: { calendarData: any[]; currency?: string }) {
  const [current, setCurrent] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<{ date: string; entry: any } | null>(null);
  const [selectedWeek, setSelectedWeek] = useState<{ week: number; pnl: number; days: number; count: number } | null>(null);
  const dataMap = new Map(calendarData.map((d) => [d.date, d]));

  const start = startOfMonth(current);
  const end = endOfMonth(current);
  const days = eachDayOfInterval({ start, end });
  const startDow = getDay(start);

  function summarizeWeek(wdays: any[]) {
    let pnl = 0, tradeDays = 0, tradeCount = 0;
    for (const d of wdays) {
      if (!d) continue;
      const entry = dataMap.get(format(d, "yyyy-MM-dd"));
      if (entry) { pnl += entry.pnl; tradeDays++; tradeCount += entry.tradeCount; }
    }
    return { pnl, tradeDays, tradeCount };
  }

  const weeks: (Date | null)[][] = [];
  let week: (Date | null)[] = Array(startDow).fill(null);
  for (const day of days) {
    week.push(day);
    if (week.length === 7) { weeks.push(week); week = []; }
  }
  if (week.length > 0) { while (week.length < 7) week.push(null); weeks.push(week); }

  const totalPnl = calendarData
    .filter((d) => d.date.startsWith(format(current, "yyyy-MM")))
    .reduce((s, d) => s + d.pnl, 0);
  const totalTradeDays = calendarData.filter((d) => d.date.startsWith(format(current, "yyyy-MM"))).length;

  function getCellColors(pnl: number) {
    const isDark = typeof window !== "undefined" && document.documentElement.classList.contains("dark");
    if (pnl > 0) return isDark
      ? { bg: "rgba(22,163,74,0.2)", border: "rgba(22,163,74,0.6)", text: "#86efac" }
      : { bg: "#f0fdf4", border: "#86efac", text: "#15803d" };
    if (pnl < 0) return isDark
      ? { bg: "rgba(220,38,38,0.2)", border: "rgba(220,38,38,0.6)", text: "#fca5a5" }
      : { bg: "#fff1f2", border: "#fca5a5", text: "#b91c1c" };
    return { bg: "transparent", border: "hsl(var(--border))", text: "#64748b" };
  }

  const fmtPnl = (v: number) => formatCurrency(v, currency ?? "USD");

  return (
    <div className="bg-card border rounded-xl p-3">
      {/* Header */}
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-1.5">
          <button onClick={() => setCurrent(subMonths(current, 1))} className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-muted transition-colors border">
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <span className="text-xs font-semibold min-w-[110px] text-center">{format(current, "MMMM yyyy")}</span>
          <button onClick={() => setCurrent(addMonths(current, 1))} className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-muted transition-colors border">
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => setCurrent(new Date())} className="text-[10px] px-2 py-1 rounded-lg border text-muted-foreground hover:bg-muted transition-colors">
            Now
          </button>
        </div>
        <div className="flex items-center gap-2">
          <span className={cn("font-semibold text-xs", totalPnl >= 0 ? "text-[#16a34a]" : "text-[#dc2626]")}>{fmtPnl(totalPnl)}</span>
          <span className="text-[10px] text-muted-foreground">{totalTradeDays}d</span>
        </div>
      </div>

      {/* Day headers */}
      <div className="grid grid-cols-8 gap-1 mb-1.5">
        {["S","M","T","W","T","F","S","Wk"].map((d, i) => (
          <div key={i} className="text-center text-[9px] font-medium text-muted-foreground">{d}</div>
        ))}
      </div>

      {/* Weeks */}
      {weeks.map((wk, wi) => {
        const { pnl: wPnl, tradeDays: wDays, tradeCount: wTrades } = summarizeWeek(wk);
        const wColors = wDays > 0 ? getCellColors(wPnl) : null;
        return (
          <div key={wi} className="grid grid-cols-8 gap-1 mb-1">
            {wk.map((day, di) => {
              if (!day) return <div key={di} className="rounded-xl border border-dashed border-border/30 h-10 md:h-16" />;
              const key = format(day, "yyyy-MM-dd");
              const entry = dataMap.get(key);
              const c = entry ? getCellColors(entry.pnl) : null;
              const isToday = key === format(new Date(), "yyyy-MM-dd");
              return (
                <div key={di}
                  role={entry ? "button" : undefined}
                  onClick={() => { if (entry) setSelectedDay({ date: key, entry }); }}
                  className="rounded-xl border h-10 md:h-16 p-1 md:p-2 flex flex-col justify-between cal-cell"
                  style={c
                    ? { background: c.bg, borderColor: c.border, cursor: entry ? "pointer" : "default" }
                    : { background: "var(--card)", borderColor: isToday ? "#6366f1" : "hsl(var(--border))", cursor: entry ? "pointer" : "default" }
                  }>
                  <p className={cn("text-[9px] font-semibold leading-none", isToday && !c ? "text-indigo-500" : "text-muted-foreground")}>
                    {format(day, "d")}
                  </p>
                  {entry && (
                    <>
                      <p className="text-[7px] md:text-[11px] font-bold leading-none truncate" style={{ color: c?.text }}>
                        {fmtPnl(entry.pnl)}
                      </p>
                      <p className="text-[6px] md:text-[9px] leading-none" style={{ color: c?.text, opacity: 0.7 }}>
                        {entry.tradeCount} {entry.tradeCount === 1 ? "Trade" : "Trades"}
                      </p>
                    </>
                  )}
                </div>
              );
            })}
            {/* Week summary */}
            <div className="rounded-xl border h-10 md:h-16 p-1 md:p-2 flex flex-col justify-between"
              role={wDays > 0 ? "button" : undefined}
              onClick={() => { if (wDays > 0) setSelectedWeek({ week: wi + 1, pnl: wPnl, days: wDays, count: wTrades }); }}
              style={wColors ? { background: wColors.bg, borderColor: wColors.border, cursor: wDays > 0 ? "pointer" : "default" } : { borderColor: "hsl(var(--border))", cursor: wDays > 0 ? "pointer" : "default" }}>
              <p className="text-[7px] md:text-[10px] text-muted-foreground leading-none">W{wi + 1}</p>
              <p className="text-[7px] md:text-[11px] font-bold leading-none truncate" style={{ color: wColors ? wColors.text : "hsl(var(--muted-foreground))" }}>
                {fmtPnl(wDays > 0 ? wPnl : 0)}
              </p>
              {wTrades > 0 && (
                <p className="text-[6px] md:text-[9px] leading-none" style={{ color: wColors ? wColors.text : "hsl(var(--muted-foreground))", opacity: 0.7 }}>
                  {wTrades} {wTrades === 1 ? "Trade" : "Trades"}
                </p>
              )}
            </div>
          </div>
        );
      })}
      {/* Day popup */}
      {selectedDay && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4" onClick={() => setSelectedDay(null)}>
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm anim-fade" />
          <div className="relative bg-card border rounded-2xl p-5 w-full max-w-sm shadow-2xl anim-pop" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-xs text-muted-foreground">Trading Day</p>
                <p className="text-sm font-semibold">{format(new Date(selectedDay.date + "T00:00:00"), "EEEE, d MMMM yyyy")}</p>
              </div>
              <button onClick={() => setSelectedDay(null)} className="w-7 h-7 flex items-center justify-center rounded-full hover:bg-muted text-muted-foreground">✕</button>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-muted/40 rounded-xl p-3">
                <p className="text-[10px] text-muted-foreground mb-1">Net P&L</p>
                <p className={cn("text-sm font-bold", selectedDay.entry.pnl > 0 ? "text-[#16a34a]" : "text-[#dc2626]")}>
                  {formatCurrency(selectedDay.entry.pnl, currency)}
                </p>
              </div>
              <div className="bg-muted/40 rounded-xl p-3">
                <p className="text-[10px] text-muted-foreground mb-1">Total Trades</p>
                <p className="text-sm font-bold">{selectedDay.entry.tradeCount}</p>
              </div>
            </div>
            <div className={cn("rounded-xl p-3 text-center", selectedDay.entry.pnl > 0 ? "bg-[#16a34a]/10" : "bg-[#dc2626]/10")}>
              <p className={cn("text-xs font-semibold", selectedDay.entry.pnl > 0 ? "text-[#16a34a]" : "text-[#dc2626]")}>
                {selectedDay.entry.pnl > 0 ? "✓ Profitable Day" : selectedDay.entry.pnl < 0 ? "✗ Loss Day" : "Break Even"}
              </p>
            </div>
            <button onClick={() => setSelectedDay(null)} className="w-full mt-3 py-2 text-xs text-muted-foreground">Close</button>
          </div>
        </div>
      )}

      {/* Week popup */}
      {selectedWeek && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4" onClick={() => setSelectedWeek(null)}>
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm anim-fade" />
          <div className="relative bg-card border rounded-2xl p-5 w-full max-w-sm shadow-2xl anim-pop" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-xs text-muted-foreground">{format(current, "MMMM yyyy")}</p>
                <p className="text-sm font-semibold">Week {selectedWeek.week}</p>
              </div>
              <button onClick={() => setSelectedWeek(null)} className="w-7 h-7 flex items-center justify-center rounded-full hover:bg-muted text-muted-foreground">✕</button>
            </div>
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="bg-muted/40 rounded-xl p-3">
                <p className="text-[10px] text-muted-foreground mb-1">Net P&L</p>
                <p className={cn("text-sm font-bold", selectedWeek.pnl > 0 ? "text-[#16a34a]" : "text-[#dc2626]")}>
                  {formatCurrency(selectedWeek.pnl, currency)}
                </p>
              </div>
              <div className="bg-muted/40 rounded-xl p-3">
                <p className="text-[10px] text-muted-foreground mb-1">Trade Days</p>
                <p className="text-sm font-bold">{selectedWeek.days}</p>
              </div>
              <div className="bg-muted/40 rounded-xl p-3">
                <p className="text-[10px] text-muted-foreground mb-1">Trades</p>
                <p className="text-sm font-bold">{selectedWeek.count}</p>
              </div>
            </div>
            <div className={cn("rounded-xl p-3 text-center", selectedWeek.pnl > 0 ? "bg-[#16a34a]/10" : "bg-[#dc2626]/10")}>
              <p className={cn("text-xs font-semibold", selectedWeek.pnl > 0 ? "text-[#16a34a]" : "text-[#dc2626]")}>
                {selectedWeek.pnl > 0 ? "✓ Profitable Week" : selectedWeek.pnl < 0 ? "✗ Loss Week" : "Break Even"}
              </p>
            </div>
            <button onClick={() => setSelectedWeek(null)} className="w-full mt-3 py-2 text-xs text-muted-foreground">Close</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function DashboardPage() {
  const [period, setPeriod] = useState("all");
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedAccountId, setSelectedAccountId] = useState<string>("");
  const [accountOpen, setAccountOpen] = useState(false);
  const [equityView, setEquityView] = useState<"daily"|"weekly"|"monthly">("daily");
  const [goalInput, setGoalInput] = useState("");
  const [showTxModal, setShowTxModal] = useState(false);
  const [txType, setTxType] = useState<"deposit"|"withdraw">("deposit");
  const [txAmount, setTxAmount] = useState("");
  const [txNote, setTxNote] = useState("");
  const [txDate, setTxDate] = useState("");
  const [txList, setTxList] = useState<any[]>([]);
  const [savingTx, setSavingTx] = useState(false);
  const [editingGoal, setEditingGoal] = useState(false);
  const [savingGoal, setSavingGoal] = useState(false);

  const fetchData = useCallback(() => {
    setLoading(true);
    const params = new URLSearchParams({ period });
    if (selectedAccountId) params.set("accountId", selectedAccountId);
    fetch(`/api/dashboard?${params}`)
      .then((r) => r.json())
      .then((d) => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, [period, selectedAccountId]);

  useEffect(() => { fetchData(); }, [fetchData]);
  useEffect(() => {
    if (Array.isArray(data?.transactions)) setTxList(data.transactions);
  }, [data]);

  const stats = data?.stats;
  const equityCurve = data?.equityCurve ?? [];
  const bySymbol = data?.bySymbol ?? [];
  const bySession = data?.bySession ?? [];
  const recentTrades = data?.recentTrades ?? [];
  const calendar = data?.calendar ?? [];

  const bestDay = calendar.length ? calendar.reduce((a: any, b: any) => b.pnl > a.pnl ? b : a, calendar[0]) : null;
  const worstDay = calendar.length ? calendar.reduce((a: any, b: any) => b.pnl < a.pnl ? b : a, calendar[0]) : null;

  const rawCurve = equityCurve.length > 0
    ? equityCurve.map((p: any) => ({
        date: p.date,
        pnl: Math.round((p.balance - (data?.account?.initialBalance ?? 0)) * 100) / 100,
      }))
    : (() => {
        let running = 0;
        return calendar
          .slice()
          .sort((a: any, b: any) => a.date.localeCompare(b.date))
          .map((d: any) => { running += d.pnl; return { date: d.date, pnl: Math.round(running * 100) / 100 }; });
      })();

  // Aggregate equity curve by view
  const aggregateEquity = (view: "daily"|"weekly"|"monthly") => {
    if (!rawCurve.length) return [];
    if (view === "daily") return rawCurve.map((p: any) => ({ ...p, date: p.date.slice(5) }));
    const map = new Map<string, number>();
    for (const p of rawCurve) {
      const d = new Date(p.date);
      let key = "";
      if (view === "weekly") {
        const weekStart = new Date(d);
        weekStart.setDate(d.getDate() - d.getDay());
        key = weekStart.toISOString().slice(0, 10).slice(5);
      } else {
        key = p.date.slice(0, 7).replace("-", "/");
      }
      map.set(key, p.pnl); // ambil nilai terakhir per period
    }
    return Array.from(map.entries()).map(([date, pnl]) => ({ date, pnl }));
  };

  const cumulativeCurve = aggregateEquity(equityView);

  // Earnings stats
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const weekStart = new Date(now); weekStart.setDate(now.getDate() - now.getDay());
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
  const weekStartStr = weekStart.toISOString().slice(0, 10);

  const sumPnl = (from: string, to?: string) => calendar
    .filter((d: any) => d.date >= from && (!to || d.date <= (to ?? todayStr)))
    .reduce((s: number, d: any) => s + d.pnl, 0);

  const todayPnl = sumPnl(todayStr);
  const weekPnl = sumPnl(weekStartStr);
  const monthPnl = sumPnl(monthStart);

  // Prev period for % change
  const prevDayStr = new Date(now.getTime() - 86400000).toISOString().slice(0, 10);
  const prevWeekStart = new Date(weekStart.getTime() - 7 * 86400000).toISOString().slice(0, 10);
  const prevMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().slice(0, 10);
  const prevMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0).toISOString().slice(0, 10);

  const prevDayPnl = sumPnl(prevDayStr, prevDayStr);
  const prevWeekPnl = sumPnl(prevWeekStart, new Date(weekStart.getTime() - 1).toISOString().slice(0, 10));
  const prevMonthPnl = sumPnl(prevMonthStart, prevMonthEnd);

  const pctChange = (cur: number, prev: number) => prev === 0 ? null : ((cur - prev) / Math.abs(prev)) * 100;

  const monthlyGoal = data?.account?.monthlyGoal ?? 0;
  const goalPct = monthlyGoal > 0 ? Math.min(100, (monthPnl / monthlyGoal) * 100) : 0;

  async function fetchTransactions(accId: string) {
    const res = await fetch(`/api/transactions?accountId=${accId}`);
    const d = await res.json();
    setTxList(Array.isArray(d) ? d : []);
  }

  async function saveTx() {
    if (!data?.account?.id || !txAmount) return;
    setSavingTx(true);
    await fetch("/api/transactions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        accountId: data.account.id,
        type: txType,
        amount: parseFloat(txAmount.replace(/[^0-9.]/g, "")),
        note: txNote,
        date: txDate || undefined,
      }),
    });
    setSavingTx(false);
    setTxAmount("");
    setTxNote("");
    setTxDate("");
    setShowTxModal(false);
    fetchData();
    fetchTransactions(data.account.id);
  }

  async function deleteTx(id: string) {
    await fetch(`/api/transactions?id=${id}`, { method: "DELETE" });
    if (data?.account?.id) fetchTransactions(data.account.id);
    fetchData();
  }

  async function saveGoal() {
    if (!data?.account?.id) return;
    setSavingGoal(true);
    await fetch(`/api/accounts/${data.account.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ monthlyGoal: parseFloat(goalInput) || 0 }),
    });
    setSavingGoal(false);
    setEditingGoal(false);
    fetchData();
  }

  const dailyBarData = calendar
    .slice()
    .sort((a: any, b: any) => a.date.localeCompare(b.date))
    .map((d: any) => ({ date: d.date.slice(5), pnl: Math.round(d.pnl * 100) / 100 }));

  const dowPnl: Record<number, { pnl: number; count: number }> = {};
  for (const d of calendar) {
    const dow = getDay(new Date(d.date));
    if (!dowPnl[dow]) dowPnl[dow] = { pnl: 0, count: 0 };
    dowPnl[dow].pnl += d.pnl;
    dowPnl[dow].count += d.tradeCount;
  }
  const dowEntries = Object.entries(dowPnl);
  const mostProfitableDoW = dowEntries.length ? dowEntries.reduce((a, b) => b[1].pnl > a[1].pnl ? b : a) : null;
  const mostActiveDoW = dowEntries.length ? dowEntries.reduce((a, b) => b[1].count > a[1].count ? b : a) : null;

  const avgDuration = (() => {
    const withDuration = recentTrades.filter((t: any) => t.exitDate && t.entryDate);
    if (!withDuration.length) return null;
    const avgMs = withDuration.reduce((s: number, t: any) =>
      s + (new Date(t.exitDate).getTime() - new Date(t.entryDate).getTime()), 0
    ) / withDuration.length;
    const h = Math.floor(avgMs / 3600000);
    const m = Math.floor((avgMs % 3600000) / 60000);
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  })();

  const sessionLabel: Record<string, string> = {
    london: "London", newyork: "New York", asia: "Asia", sydney: "Sydney", unknown: "Unknown",
  };

  const cur = data?.account?.currency ?? "USD";
  const sym = cur === "IDR" ? "Rp" : "$";
  const fmtK = (v: number) => {
    const abs = Math.abs(v);
    const sign = v >= 0 ? "+" : "-";
    if (abs >= 1_000_000_000) return `${sign}${sym}${(abs/1_000_000_000).toFixed(1)}B`;
    if (abs >= 1_000_000) return `${sign}${sym}${(abs/1_000_000).toFixed(1)}M`;
    if (abs >= 1_000) return `${sign}${sym}${(abs/1_000).toFixed(0)}K`;
    return formatCurrency(v, cur);
  };

  return (
    <div className="p-4 space-y-4 min-h-screen">
      {/* ── HEADER ── */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold tracking-tight">Dashboard</span>
          {data?.accounts && data.accounts.length > 0 && (
            <div className="relative">
              <button onClick={() => setAccountOpen(!accountOpen)}
                className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 hover:border-indigo-400 transition-colors">
                <span className="truncate max-w-[120px]">{data.account?.name ?? "Select"}</span>
                <svg className="w-3 h-3 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
              </button>
              {accountOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setAccountOpen(false)} />
                  <div className="absolute left-0 top-8 z-50 min-w-[180px] border rounded-xl shadow-2xl py-1 overflow-hidden" style={{ backgroundColor: "hsl(var(--card))" }}>
                    {data.accounts.map((acc: any) => (
                      <button key={acc.id} onClick={() => { setSelectedAccountId(acc.id); setAccountOpen(false); }}
                        className={cn("w-full text-left px-3 py-2 text-xs hover:bg-muted transition-colors flex items-center justify-between gap-2",
                          (selectedAccountId === acc.id || (!selectedAccountId && acc.isDefault)) && "text-indigo-400 font-medium")}>
                        <span className="truncate">{acc.name}</span>
                        {(selectedAccountId === acc.id || (!selectedAccountId && acc.isDefault)) && (
                          <svg className="w-3 h-3 shrink-0 text-indigo-400" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                        )}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}
        </div>
        <div className="flex items-center gap-1">
          {PERIODS.map((p) => (
            <button key={p.value} onClick={() => setPeriod(p.value)}
              className={cn("text-[11px] px-2.5 py-1 rounded-lg transition-colors font-medium",
                period === p.value ? "bg-indigo-600 text-white" : "text-muted-foreground hover:text-foreground hover:bg-muted")}>
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
            {[0, 1, 2, 3].map((i) => <div key={i} className="skeleton h-32 rounded-2xl" />)}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_340px] gap-3">
            <div className="skeleton h-[330px] rounded-2xl" />
            <div className="skeleton h-[330px] rounded-2xl" />
          </div>
        </div>
      ) : (
        <>
          {/* ── ROW 1: KPI (Win %, Avg W/L, Profit Factor, Streak) ── */}
          <KpiRow stats={stats} calendar={calendar} currency={cur} />

          {/* ── ROW 2: NET P&L + DAY EXTREMES ── */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 stagger">
            <div className="rounded-2xl p-4 border relative overflow-hidden card-hover"
              style={{
                background: stats?.netPnL >= 0 ? "linear-gradient(135deg, rgba(22,163,74,0.14), rgba(22,163,74,0.04))" : "linear-gradient(135deg, rgba(220,38,38,0.14), rgba(220,38,38,0.04))",
                borderColor: stats?.netPnL >= 0 ? "rgba(22,163,74,0.3)" : "rgba(220,38,38,0.3)",
              }}>
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">Net P&L</p>
              <p className={cn("text-2xl font-bold tracking-tight", stats?.netPnL >= 0 ? "text-[#4ade80]" : "text-[#f87171]")}>
                {stats ? formatCurrency(stats.netPnL, cur) : "—"}
              </p>
              <p className="text-[10px] text-muted-foreground mt-1">{stats?.closedTrades ?? 0} trades closed</p>
            </div>
            <StatCard label="Best Day" value={bestDay ? fmtK(bestDay.pnl) : "—"} sub={bestDay ? format(new Date(bestDay.date), "EEE, MMM d") : undefined} color={bestDay?.pnl > 0 ? "text-[#4ade80]" : undefined} />
            <StatCard label="Worst Day" value={worstDay ? fmtK(worstDay.pnl) : "—"} sub={worstDay ? format(new Date(worstDay.date), "EEE, MMM d") : undefined} color={worstDay?.pnl < 0 ? "text-[#f87171]" : undefined} />
            <StatCard label="Avg Hold" value={avgDuration ?? "—"} sub="per trade" />
          </div>

          {/* ── ROW 3: EQUITY CURVE + TRADE SCORE ── */}
          <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_340px] gap-3 stagger">
            <div className="min-w-0 rounded-2xl border bg-card p-4 card-hover">
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs font-semibold">Equity Curve</p>
                <div className="flex items-center gap-0.5 bg-muted/50 rounded-lg p-0.5">
                  {(["daily", "weekly", "monthly"] as const).map((v) => (
                    <button key={v} onClick={() => setEquityView(v)}
                      className={cn("text-[9px] px-2 py-0.5 rounded-md font-medium transition-colors capitalize",
                        equityView === v ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground")}>
                      {v.slice(0, 1).toUpperCase() + v.slice(1, 3)}
                    </button>
                  ))}
                </div>
              </div>
              {cumulativeCurve.length > 0 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <AreaChart data={cumulativeCurve} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={CURVE_COLOR} stopOpacity={0.4} />
                        <stop offset="100%" stopColor={CURVE_COLOR} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                    <XAxis dataKey="date" tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }} width={48} axisLine={false} tickLine={false}
                      tickFormatter={(v) => { const a = Math.abs(v); return a >= 1e9 ? `${sym}${(v / 1e9).toFixed(1)}B` : a >= 1e6 ? `${sym}${(v / 1e6).toFixed(1)}M` : a >= 1e3 ? `${sym}${(v / 1e3).toFixed(0)}K` : `${sym}${v}`; }} />
                    <ReferenceLine y={0} stroke="rgba(255,255,255,0.1)" strokeDasharray="4 2" />
                    <Tooltip formatter={(v: number) => [formatCurrency(v, cur, true), "Equity"]} contentStyle={TOOLTIP_STYLE} labelStyle={{ color: "rgba(255,255,255,0.5)" }} itemStyle={{ color: CURVE_COLOR }} />
                    <Area type="monotone" dataKey="pnl" stroke={CURVE_COLOR} strokeWidth={2} fill="url(#eqGrad)" isAnimationActive animationDuration={1400} animationEasing="ease-out" dot={false} activeDot={{ r: 4, fill: CURVE_COLOR, strokeWidth: 0 }} />
                  </AreaChart>
                </ResponsiveContainer>
              ) : <div className="h-44 flex items-center justify-center text-xs text-muted-foreground">No data yet</div>}
            </div>
            <TradeScoreCard stats={stats} calendar={calendar} account={data?.account} />
          </div>

          {/* ── ROW 4: EARNINGS + GOAL ── */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 stagger">
            {/* Earnings */}
            <div className="rounded-2xl border bg-card p-4 card-hover">
              <p className="text-xs font-semibold mb-3">Earnings</p>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: "Today", pnl: todayPnl, prev: prevDayPnl },
                  { label: "This Week", pnl: weekPnl, prev: prevWeekPnl },
                  { label: "This Month", pnl: monthPnl, prev: prevMonthPnl },
                ].map(({ label, pnl, prev }) => {
                  const pct = pctChange(pnl, prev);
                  return (
                    <div key={label} className="bg-muted/30 rounded-xl p-2.5">
                      <p className="text-[9px] text-muted-foreground mb-1 uppercase tracking-wide">{label}</p>
                      <p className={cn("text-xs font-bold", pnl >= 0 ? "text-[#4ade80]" : "text-[#f87171]")}>{fmtK(pnl)}</p>
                      {pct !== null && (
                        <p className={cn("text-[9px] mt-0.5", pct >= 0 ? "text-[#4ade80]" : "text-[#f87171]")}>
                          {pct >= 0 ? "▲" : "▼"} {Math.abs(pct).toFixed(0)}%
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Monthly Goal */}
            <div className="rounded-2xl border bg-card p-4 card-hover">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-semibold">Monthly Goal</p>
                <button onClick={() => { setEditingGoal(true); setGoalInput(String(monthlyGoal || "")); }}
                  className="text-[10px] text-indigo-400 hover:underline">{monthlyGoal > 0 ? "Edit" : "Set Goal"}</button>
              </div>
              {editingGoal ? (
                <div className="flex items-center gap-2 mt-2">
                  <input type="number" value={goalInput} onChange={e => setGoalInput(e.target.value)} placeholder="e.g. 10000000"
                    className="flex-1 text-xs border rounded-xl px-2 py-1.5 bg-background" />
                  <button onClick={saveGoal} disabled={savingGoal} className="text-[10px] px-2.5 py-1.5 bg-indigo-600 text-white rounded-xl disabled:opacity-50">{savingGoal ? "..." : "Save"}</button>
                  <button onClick={() => setEditingGoal(false)} className="text-[10px] text-muted-foreground">✕</button>
                </div>
              ) : monthlyGoal > 0 ? (
                <div className="flex items-center gap-4">
                  <div className="relative w-28 h-14">
                    <svg viewBox="0 0 120 60" className="w-full h-full">
                      <defs><filter id="glow2"><feGaussianBlur stdDeviation="3" result="cb"/><feMerge><feMergeNode in="cb"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
                      <path d="M 8 60 A 52 52 0 0 1 112 60" fill="none" stroke="hsl(var(--muted))" strokeWidth="10" strokeLinecap="round"/>
                      <path d="M 8 60 A 52 52 0 0 1 112 60" fill="none" stroke={goalPct >= 100 ? "#4ade80" : "#818cf8"} strokeWidth="10" strokeLinecap="round"
                        strokeDasharray={`${Math.min(goalPct,100)*1.634} 163.4`} filter="url(#glow2)"/>
                      <text x="60" y="52" textAnchor="middle" fontSize="13" fontWeight="bold" fill={goalPct >= 100 ? "#4ade80" : "#818cf8"}>{goalPct.toFixed(0)}%</text>
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className={cn("text-sm font-bold", monthPnl >= 0 ? "text-[#4ade80]" : "text-[#f87171]")}>{fmtK(monthPnl)}</p>
                    <p className="text-[10px] text-muted-foreground">of {formatCurrency(monthlyGoal, cur, false)}</p>
                    <p className="text-[10px] text-muted-foreground mt-1">{goalPct >= 100 ? "🎉 Achieved!" : `${fmtK(monthlyGoal - monthPnl).replace("+","")} left`}</p>
                  </div>
                </div>
              ) : (
                <div className="h-16 flex items-center justify-center text-xs text-muted-foreground">Set a monthly profit goal</div>
              )}
            </div>
          {/* By Session */}
            <div className="rounded-2xl border bg-card p-4 card-hover">
              <p className="text-xs font-semibold mb-3">By Session</p>
              <div className="space-y-2.5">
                {bySession.length === 0 && <p className="text-xs text-muted-foreground">No data</p>}
                {bySession.slice(0, 4).map((s: any) => (
                  <div key={s.session} className="flex items-center gap-2">
                    <span className="text-[10px] text-muted-foreground w-16 truncate capitalize">{sessionLabel[s.session] ?? s.session}</span>
                    <div className="flex-1 h-1.5 bg-muted/50 rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-indigo-500" style={{ width: `${s.winRate}%` }} />
                    </div>
                    <span className="text-[10px] font-medium w-8 text-right">{s.winRate}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* ── ROW 5: CALENDAR + RECENT TRADES ── */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-3 stagger">
            <div className="lg:col-span-3">
              <CalendarHeatmap calendarData={calendar} currency={data?.account?.currency} />
            </div>
            <div className="rounded-2xl border bg-card p-4 flex flex-col card-hover">
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs font-semibold">Recent Trades</p>
                <Link href="/trades" className="text-[10px] text-indigo-400 hover:underline">View all →</Link>
              </div>
              <div className="space-y-0 flex-1 overflow-y-auto">
                {recentTrades.length === 0 ? (
                  <p className="text-xs text-muted-foreground py-4 text-center">No trades yet</p>
                ) : recentTrades.map((t: any) => (
                  <div key={t.id} className="flex items-center justify-between py-2 border-b last:border-0 row-hover">
                    <div>
                      <p className="text-[11px] font-semibold">{t.symbol}</p>
                      <p className="text-[9px] text-muted-foreground">{format(new Date(t.entryDate), "dd MMM")}</p>
                    </div>
                    {t.pnl !== null ? (
                      <span className={cn("text-[11px] font-bold px-1.5 py-0.5 rounded-md",
                        t.pnl > 0 ? "bg-[#16a34a]/20 text-[#4ade80]" : t.pnl < 0 ? "bg-[#dc2626]/20 text-[#f87171]" : "bg-muted text-muted-foreground")}>
                        {fmtK(t.pnl)}
                      </span>
                    ) : <span className="text-[10px] text-muted-foreground">open</span>}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* ── ROW 6: DEPOSIT & WITHDRAW ── */}
          <div className="rounded-2xl border bg-card p-4 card-hover anim-up" style={{ animationDelay: ".3s" }}>
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-semibold">Deposit & Withdraw</p>
              <button onClick={() => setShowTxModal(true)} className="text-[10px] px-2.5 py-1 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">+ Add</button>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="rounded-xl p-3 bg-[#16a34a]/10 border border-[#16a34a]/20">
                <p className="text-[10px] text-muted-foreground mb-1">Total Deposit</p>
                <p className="text-sm font-bold text-[#4ade80]">{formatCurrency(data?.account?.totalDeposit ?? 0, cur, false)}</p>
              </div>
              <div className="rounded-xl p-3 bg-[#dc2626]/10 border border-[#dc2626]/20">
                <p className="text-[10px] text-muted-foreground mb-1">Total Withdraw</p>
                <p className="text-sm font-bold text-[#f87171]">{formatCurrency(data?.account?.totalWithdraw ?? 0, cur, false)}</p>
              </div>
            </div>
            {txList.length > 0 && (
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {txList.slice(0, 5).map((tx: any) => (
                  <div key={tx.id} className="flex items-center justify-between py-1.5 border-b last:border-0">
                    <div className="flex items-center gap-2">
                      <span className={cn("text-[9px] px-1.5 py-0.5 rounded font-medium", tx.type === "deposit" ? "bg-[#16a34a]/20 text-[#4ade80]" : "bg-[#dc2626]/20 text-[#f87171]")}>
                        {tx.type === "deposit" ? "DEP" : "WDR"}
                      </span>
                      <div>
                        <p className="text-[10px] font-medium">{formatCurrency(tx.amount, cur, false)}</p>
                        {tx.note && <p className="text-[9px] text-muted-foreground">{tx.note}</p>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <p className="text-[9px] text-muted-foreground">{new Date(tx.date).toLocaleDateString("id-ID", { day: "2-digit", month: "short" })}</p>
                      <button onClick={() => deleteTx(tx.id)} className="text-muted-foreground hover:text-[#f87171] text-[10px]">✕</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {/* Add Transaction Modal */}
      {showTxModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4" onClick={() => setShowTxModal(false)}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm anim-fade" />
          <div className="relative bg-card border rounded-2xl p-5 w-full max-w-sm shadow-2xl anim-pop" onClick={e => e.stopPropagation()}>
            <p className="text-sm font-semibold mb-4">Add Transaction</p>
            <div className="flex gap-2 mb-4">
              {(["deposit","withdraw"] as const).map(t => (
                <button key={t} onClick={() => setTxType(t)}
                  className={cn("flex-1 py-2 rounded-xl text-xs font-medium capitalize transition-colors", txType === t ? t === "deposit" ? "bg-[#16a34a] text-white" : "bg-[#dc2626] text-white" : "bg-muted text-muted-foreground")}>
                  {t}
                </button>
              ))}
            </div>
            <div className="space-y-3">
              <div><label className="text-[10px] text-muted-foreground">Amount ({cur})</label>
                <input type="number" value={txAmount} onChange={e => setTxAmount(e.target.value)} placeholder="0" className="w-full mt-1 text-sm border rounded-xl px-3 py-2 bg-background" /></div>
              <div><label className="text-[10px] text-muted-foreground">Note (optional)</label>
                <input type="text" value={txNote} onChange={e => setTxNote(e.target.value)} placeholder="e.g. Initial deposit" className="w-full mt-1 text-xs border rounded-xl px-3 py-2 bg-background" /></div>
              <div><label className="text-[10px] text-muted-foreground">Date (optional)</label>
                <input type="date" value={txDate} onChange={e => setTxDate(e.target.value)} className="w-full mt-1 text-xs border rounded-xl px-3 py-2 bg-background" /></div>
            </div>
            <button onClick={saveTx} disabled={savingTx || !txAmount} className="w-full mt-4 py-2.5 bg-indigo-600 text-white text-xs font-medium rounded-xl hover:bg-indigo-700 disabled:opacity-50">
              {savingTx ? "Saving..." : `Add ${txType}`}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
