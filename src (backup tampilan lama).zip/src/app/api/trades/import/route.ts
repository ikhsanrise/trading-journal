export const maxDuration = 60;

// src/app/api/trades/import/route.ts
import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import Papa from "papaparse";
import { calculateRMultiple, getOutcomeFromR } from "@/lib/utils";

function parseDate(str: string): Date | null {
  if (!str || str.trim() === "") return null;
  // Format: 2026.06.22 06:14:59
  const dotFmt = str.match(/^(\d{4})\.(\d{2})\.(\d{2})\s+(\d{2}:\d{2}:\d{2})$/);
  if (dotFmt) return new Date(`${dotFmt[1]}-${dotFmt[2]}-${dotFmt[3]}T${dotFmt[4]}`);
  return new Date(str);
}

// Format HFM/MT5: Time,Position,Symbol,Type,Volume,Price,S/L,T/P,Time,Price,Commission,Swap,Profit
function parseHFMRow(row: any) {
  const keys = Object.keys(row);
  // Kolom Time ada 2x, papaparse akan buat Time dan Time_1
  const entryTime = row["Time"] ?? row["Open Time"] ?? "";
  const exitTime = row["Time_1"] ?? row["Close Time"] ?? "";
  const entryPrice = parseNum(row["Price"]);
  const exitPrice = parseNum(row["Price_1"] ?? row["Close Price"]) || null;
  const type = (row["Type"] ?? row["type"] ?? "").toLowerCase();
  const sl = parseNum(row["S / L"] ?? row["SL"]) || null;
  const tp = parseNum(row["T / P"] ?? row["TP"]) || null;
  const pnl = parseNum(row["Profit"]);
  const commission = parseNum(row["Commission"]);
  const swap = parseNum(row["Swap"]);
  const lotSize = parseNum(row["Volume"] ?? row["Size"]);
  const symbol = (row["Symbol"] ?? "").replace(/r$/, ""); // hapus suffix 'r' pada XAUUSDr

  return {
    symbol,
    direction: type.includes("buy") ? "long" : "short",
    entryPrice,
    exitPrice,
    stopLoss: sl,
    takeProfit: tp,
    lotSize,
    entryDate: entryTime,
    exitDate: exitTime,
    pnl,
    commission,
    swap,
    rMultiple: null as number | null,
    outcome: null as string | null,
  };
}

// Format Trading Journal export: Date,Symbol,Direction,Entry Price,Exit Price,...
function parseJournalRow(row: any) {
  return {
    symbol: row["Symbol"] ?? "",
    direction: (row["Direction"] ?? "long").toLowerCase(),
    entryPrice: parseFloat(row["Entry Price"] ?? 0),
    exitPrice: parseFloat(row["Exit Price"] ?? "") || null,
    stopLoss: parseFloat(row["Stop Loss"] ?? "") || null,
    takeProfit: parseFloat(row["Take Profit"] ?? "") || null,
    lotSize: parseFloat(row["Lot Size"] ?? 0),
    entryDate: row["Entry Date"] ?? row["Date"] ?? "",
    exitDate: row["Exit Date"] ?? "",
    pnl: parseFloat(row["P&L"] ?? 0),
    commission: parseFloat(row["Commission"] ?? 0),
    swap: parseFloat(row["Swap"] ?? 0),
    rMultiple: parseFloat(row["R-Multiple"] ?? "") || null,
    outcome: row["Outcome"] ?? null,
    setup: row["Setup"] ?? null,
    setupCategory: row["Setup Category"] ?? null,
    session: row["Session"] ?? null,
    timeframe: row["Timeframe"] ?? null,
    mood: row["Mood"] ?? null,
    notes: row["Notes"] ?? null,
    tags: row["Tags"] ?? null,
  };
}

function detectSession(dateGMT0: Date): string {
  // Convert GMT+0 ke WIB (GMT+7)
  const wib = new Date(dateGMT0.getTime() + 7 * 60 * 60 * 1000);
  const hour = wib.getUTCHours(); // jam dalam WIB

  // Session dalam WIB:
  // Sydney:   05:00 - 07:00
  // Asia:     07:00 - 16:00
  // London:   16:00 - 00:00 (sampai tengah malam)
  // New York: 20:00 - 04:00 (overlap London 20:00-00:00)
  if (hour >= 20 || hour < 4) return "newyork";
  if (hour >= 16) return "london";
  if (hour >= 7) return "asia";
  if (hour >= 5) return "sydney";
  return "newyork"; // 04:00-05:00 masih NY close
}

function parseNum(val: any): number {
  if (val == null) return 0;
  const str = String(val).trim();
  if (str === "" || str === "-") return 0;
  // Handle format HFM: "4 178.90" -> 4178.90, "-134 572.25" -> -134572.25
  // Spasi adalah thousand separator, titik adalah decimal separator
  const cleaned = str.replace(/\s/g, "");
  return parseFloat(cleaned) || 0;
}

function detectFormat(headers: string[]): "hfm" | "journal" | "mt4" {
  if (headers.includes("Direction") || headers.includes("Entry Price")) return "journal";
  if (headers.includes("Volume") || headers.includes("Position")) return "hfm";
  return "mt4";
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user?.id)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const formData = await req.formData();
  const file = formData.get("file") as File;
  const accountId = formData.get("accountId") as string;

  if (!file || !accountId)
    return NextResponse.json({ error: "Missing file or accountId" }, { status: 400 });

  const account = await prisma.tradingAccount.findFirst({
    where: { id: accountId, userId: session.user.id },
  });
  if (!account)
    return NextResponse.json({ error: "Account not found" }, { status: 404 });

  let text = await file.text();
  const allLines = text.split("\n");

  // dealsOnly mode - hanya proses deposit/withdraw, skip trades
  const dealsOnly = formData.get("dealsOnly") === "true";

  // === Parse Deals section untuk deposit/withdraw ===
  let dealsStart = -1;
  for (let i = 0; i < allLines.length; i++) {
    if (allLines[i].trim().startsWith("Time,Deal,Symbol,Type")) {
      dealsStart = i + 1;
      break;
    }
  }

  if (dealsStart > 0) {
    let depTotal = 0, wdrTotal = 0;
    const txRows: { type: string; amount: number; note: string; date: Date }[] = [];

    // Fetch existing transactions untuk dedup
    const existingTx = await prisma.transaction.findMany({
      where: { accountId },
      select: { type: true, amount: true, date: true },
    });
    const existingTxKeys = new Set(
      existingTx.map(t => `${t.type}|${t.amount}|${new Date(t.date).getTime()}`)
    );

    for (let i = dealsStart; i < allLines.length; i++) {
      const row = allLines[i].split(",").map((s: string) => s.trim());
      if (!row[0] || row[0].startsWith("Results") || row[0].startsWith("Total")) break;
      const type = row[3]?.toLowerCase();
      if (type === "balance") {
        const amount = parseNum(row[11]);
        const comment = row[13] ?? "";
        const date = parseDate(row[0]) ?? new Date();
        const txKey = amount > 0
          ? `deposit|${amount}|${date.getTime()}`
          : `withdraw|${Math.abs(amount)}|${date.getTime()}`;

        if (existingTxKeys.has(txKey)) continue; // skip duplikat

        if (amount > 0) { depTotal += amount; txRows.push({ type: "deposit", amount, note: comment, date }); }
        else if (amount < 0) { wdrTotal += Math.abs(amount); txRows.push({ type: "withdraw", amount: Math.abs(amount), note: comment, date }); }
      }
    }
    if (txRows.length > 0) {
      for (const tx of txRows) {
        await prisma.transaction.create({ data: { accountId, ...tx } });
      }
      await prisma.tradingAccount.update({
        where: { id: accountId },
        data: { totalDeposit: { increment: depTotal }, totalWithdraw: { increment: wdrTotal } },
      });
    }
  }

  // Skip metadata rows untuk format HFM (baris sebelum "Positions," atau "Time,Position,")
  const lines = allLines;
  let dataStart = 0;
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i].trim();
    if (l.startsWith("Time,Position") || l.startsWith("Date,Symbol") || l.startsWith("Symbol,")) {
      dataStart = i;
      break;
    }
    // Skip baris "Positions,,,,,"
    if (l.startsWith("Positions,")) {
      dataStart = i + 1;
      break;
    }
  }
  text = lines.slice(dataStart).join("\n");

  const { data, errors } = Papa.parse(text, {
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim(),
  });

  if (errors.length > 0 && data.length === 0)
    return NextResponse.json({ error: "CSV parse error", errors }, { status: 400 });

  const headers = data.length > 0 ? Object.keys(data[0] as object) : [];
  const format = detectFormat(headers);

  const created = [];
  const failed = [];
  let totalPnl = 0;

  const tradesToCreate: any[] = [];
  for (const row of data as any[]) {
    try {
      const parsed = format === "journal" ? parseJournalRow(row) : parseHFMRow(row);
      if (!parsed.symbol || !parsed.lotSize) continue;
      if (parsed.symbol === "" || isNaN(parsed.entryPrice) || parsed.entryPrice === 0) continue;

      const status = parsed.exitDate && parsed.exitDate.trim() !== "" ? "closed" : "open";
      let rMultiple = parsed.rMultiple;
      let outcome = parsed.outcome;

      if (!rMultiple && parsed.exitPrice && parsed.stopLoss) {
        rMultiple = calculateRMultiple(parsed.direction, parsed.entryPrice, parsed.exitPrice, parsed.stopLoss);
      }
      if (!outcome) {
        if (parsed.pnl > 0) outcome = "win";
        else if (parsed.pnl < 0) outcome = "loss";
        else if (rMultiple !== null && rMultiple !== 0) outcome = getOutcomeFromR(rMultiple);
        else if (status === "closed") outcome = "breakeven";
      }

      const entryDate = parseDate(parsed.entryDate) ?? new Date();
      const exitDate = parsed.exitDate ? parseDate(parsed.exitDate) : null;
      const detectedSession = format === "hfm" ? detectSession(entryDate) : ((parsed as any).session ?? null);

      const tradeData: any = {
        accountId,
        symbol: parsed.symbol.toUpperCase(),
        direction: parsed.direction,
        entryPrice: parsed.entryPrice,
        exitPrice: parsed.exitPrice,
        stopLoss: parsed.stopLoss,
        takeProfit: parsed.takeProfit,
        lotSize: parsed.lotSize,
        entryDate,
        exitDate,
        commission: parsed.commission || 0,
        swap: parsed.swap || 0,
        pnl: parsed.pnl || 0,
        rMultiple,
        status,
        outcome,
        session: detectedSession,
      };

      if (format === "journal") {
        if ((parsed as any).timeframe) tradeData.timeframe = (parsed as any).timeframe;
        if ((parsed as any).mood) tradeData.mood = (parsed as any).mood;
        if ((parsed as any).notes) tradeData.notes = (parsed as any).notes;
        if ((parsed as any).setupCategory) tradeData.setupCategory = (parsed as any).setupCategory;
      }

      tradesToCreate.push(tradeData);
      totalPnl += parsed.pnl || 0;
    } catch (e) {
      failed.push({ error: String(e) });
    }
  }

  // Dedup: ambil existing trades untuk filter duplikat
  const existing = await prisma.trade.findMany({
    where: { accountId },
    select: { entryDate: true, symbol: true, direction: true, lotSize: true },
  });
  const existingKeys = new Set(
    existing.map(t => `${t.symbol}|${t.direction}|${t.lotSize}|${new Date(t.entryDate).getTime()}`)
  );

  const newTrades = tradesToCreate.filter(t => {
    const key = `${t.symbol}|${t.direction}|${t.lotSize}|${new Date(t.entryDate).getTime()}`;
    return !existingKeys.has(key);
  });

  const skipped = tradesToCreate.length - newTrades.length;

  // Batch insert hanya trades baru
  if (newTrades.length > 0) {
    await prisma.trade.createMany({ data: newTrades, skipDuplicates: true });
    created.push(...newTrades.map(t => t.symbol));
  }

  if (created.length > 0 && totalPnl !== 0) {
    await prisma.tradingAccount.update({
      where: { id: accountId },
      data: { currentBalance: { increment: totalPnl } },
    });
  }

  return NextResponse.json({
    imported: created.length,
    skipped,
    failed: failed.length,
    errors: failed.slice(0, 5),
    format,
  });
}
